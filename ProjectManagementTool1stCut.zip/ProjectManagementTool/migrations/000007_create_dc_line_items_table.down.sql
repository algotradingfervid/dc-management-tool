DROP INDEX IF EXISTS idx_dc_line_items_product_id;
DROP INDEX IF EXISTS idx_dc_line_items_dc_id;
DROP TABLE IF EXISTS dc_line_items;

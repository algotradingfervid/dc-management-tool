DROP INDEX IF EXISTS idx_dc_template_products_product_id;
DROP INDEX IF EXISTS idx_dc_template_products_template_id;
DROP INDEX IF EXISTS idx_dc_templates_project_id;
DROP TABLE IF EXISTS dc_template_products;
DROP TABLE IF EXISTS dc_templates;

DROP TABLE IF EXISTS company_settings;

DROP INDEX IF EXISTS idx_addresses_config_id;
DROP INDEX IF EXISTS idx_address_list_configs_project_id;
DROP TABLE IF EXISTS addresses;
DROP TABLE IF EXISTS address_list_configs;

DROP INDEX IF EXISTS idx_dc_transit_details_dc_id;
DROP INDEX IF EXISTS idx_delivery_challans_created_by;
DROP INDEX IF EXISTS idx_delivery_challans_dc_type;
DROP INDEX IF EXISTS idx_delivery_challans_status;
DROP INDEX IF EXISTS idx_delivery_challans_dc_number;
DROP INDEX IF EXISTS idx_delivery_challans_project_id;
DROP TABLE IF EXISTS dc_transit_details;
DROP TABLE IF EXISTS delivery_challans;

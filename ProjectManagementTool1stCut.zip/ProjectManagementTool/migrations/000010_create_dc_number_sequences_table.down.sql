DROP TABLE IF EXISTS dc_number_sequences;

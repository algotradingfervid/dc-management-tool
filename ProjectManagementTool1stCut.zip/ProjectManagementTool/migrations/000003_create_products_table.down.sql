DROP INDEX IF EXISTS idx_products_project_id;
DROP TABLE IF EXISTS products;

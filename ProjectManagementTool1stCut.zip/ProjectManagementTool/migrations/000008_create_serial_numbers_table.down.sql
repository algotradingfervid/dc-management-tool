DROP INDEX IF EXISTS idx_serial_numbers_serial_number;
DROP INDEX IF EXISTS idx_serial_numbers_line_item_id;
DROP TABLE IF EXISTS serial_numbers;

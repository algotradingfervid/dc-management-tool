DROP INDEX IF EXISTS idx_projects_dc_prefix;
DROP INDEX IF EXISTS idx_projects_created_by;
DROP TABLE IF EXISTS projects;
